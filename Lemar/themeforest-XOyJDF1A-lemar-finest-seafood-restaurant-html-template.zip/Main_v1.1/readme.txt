Thanks for buying :)


The documentation is in the "documentation" folder. 
The HTML is in the "HTML" folder. 
Updates are in the changelog.txt file.



If you have any question please contact me via http://velikorodnov.ticksy.com/

If you like our product, don�t forget to rate it. Thank you! :)